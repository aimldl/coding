## Update

This is an update of a data package. In this version I:

* Added a data frame containing country codes.
* Made sure all figures included from the README are actually present in the
  package (vs. only on GitHub).
* Moved supplementary data files from inst/ to inst/extdata/.

## Test environments

* local OS X install, R 3.4.1
* win-builder (devel and release)

## R CMD check results

There is one NOTE about me changing my email from jenny@stat.ubc.ca to jenny@rstudio.com.
