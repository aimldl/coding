library(here)
saveRDS(c("Gapminder", "capita"), here(".aspell", "gapminder.rds"))
