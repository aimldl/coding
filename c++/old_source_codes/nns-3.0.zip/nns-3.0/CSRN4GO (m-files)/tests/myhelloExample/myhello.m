function myhello

% An example to show usage of the mcc command
%
% Written by T. Kim, tk424@mst.edu
% Last Updated:  May. 28, 2008 (Wed)
% First Written: May. 28, 2008 (Wed)

disp('Hello, world!');
disp('My name is T!');