% A simple Matlab script
% to learn how to use the NIC cluster at MST
%
% Jul. 28, 2008 (Mon)

disp('Hello, world!');
