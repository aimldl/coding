backup on May. 9, 2008 (Thu)
 Use multiple presentation of the input data set.
