function params=initialize_parameters(params),
% A function to initialize structure parameters
%
% This structure is almost obsolete, but keeps it just in case.
params.iter_opt=1;
params.plot_results=0;
params.iteration=1;
params.iteration_max=1;
