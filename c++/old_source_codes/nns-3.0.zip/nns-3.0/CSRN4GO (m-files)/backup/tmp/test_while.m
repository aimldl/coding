% test_while

t_n=1;
t_max=10;
fitness_g=0;
fitness_t=0;


while ( (t_n<=t_max) && (fitness_g<fitness_t) ),
    disp('.');
end;