function data=init_data(data);

% init_data         Initialize structure data



if ( data.cfg.is_read==0 ),
    error('');
end;